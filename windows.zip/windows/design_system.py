"""
Дизайн-система приложения
Цвета, стили, константы
"""
import customtkinter as ctk
from typing import Tuple


class Colors:
    """Цветовая палитра в HSL формате, конвертированная в RGB"""
    
    # Основные цвета
    BACKGROUND = "#0A0514"  # hsl(258, 90%, 5%)
    BACKGROUND_GRADIENT_END = "#080410"  # hsl(258, 90%, 3%)
    FOREGROUND = "#F2EFF5"  # hsl(270, 10%, 95%)
    CARD = "#1A0F2E"  # hsl(258, 80%, 8%)
    CARD_GRADIENT_END = "#1F1538"  # hsl(258, 70%, 10%)
    PRIMARY = "#9D4EDD"  # hsl(266, 83%, 65%)
    SECONDARY = "#2A1F3D"  # hsl(258, 50%, 15%)
    MUTED_FOREGROUND = "#9995A0"  # hsl(270, 10%, 60%)
    BORDER = "#3A2F4D"  # hsl(258, 40%, 18%)
    INPUT = "#3A2F4D"  # hsl(258, 40%, 18%)
    RING = "#9D4EDD"  # hsl(266, 83%, 65%)
    
    # Цвета оценок
    GRADE_5 = "#7DD87D"  # hsl(142, 76%, 73%)
    GRADE_4 = "#2E7D32"  # hsl(142, 71%, 45%)
    GRADE_3 = "#F57C00"  # hsl(28, 80%, 52%)
    GRADE_2 = "#EF5350"  # hsl(0, 84%, 60%)
    GRADE_ABSENT = "#8B6F47"  # hsl(25, 47%, 42%)
    GRADE_EMPTY = "#4A4255"  # hsl(258, 20%, 25%)
    
    # Дополнительные цвета
    SUCCESS_GLOW = "#2E7D32"  # hsl(142, 71%, 45%)
    DESTRUCTIVE = "#EF5350"  # hsl(0, 84%, 60%)
    
    # Полупрозрачные цвета (смешанные с фоном)
    PRIMARY_LIGHT = "#27263C"  # PRIMARY с ~20% прозрачности на BACKGROUND


class Typography:
    """Типографика"""
    TITLE = ("Arial", 24, "bold")
    CARD_TITLE = ("Arial", 20, "bold")
    BASE = ("Arial", 16, "normal")
    SMALL = ("Arial", 14, "normal")
    XSMALL = ("Arial", 12, "normal")
    STATS = ("Arial", 30, "bold")


class Spacing:
    """Отступы и размеры"""
    SCREEN_PADDING = 24
    CARD_PADDING = 20
    ELEMENT_SPACING = 16
    SMALL_SPACING = 12
    FOOTER_HEIGHT = 64
    BUTTON_HEIGHT = 48
    INPUT_HEIGHT = 48
    TOUCH_TARGET = 48


class BorderRadius:
    """Радиусы скругления"""
    STANDARD = 16
    MEDIUM = 14
    SMALL = 12
    CARD = 16
    BUTTON = 8
    BADGE = 8
    CIRCLE = 50  # для круглых элементов


class DesignSystem:
    """Основной класс дизайн-системы"""
    
    @staticmethod
    def setup_theme():
        """Настроить тему CustomTkinter"""
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
    
    @staticmethod
    def get_grade_color(grade) -> str:
        """Получить цвет для оценки"""
        from models import Grade
        if grade == Grade.FIVE:
            return Colors.GRADE_5
        elif grade == Grade.FOUR:
            return Colors.GRADE_4
        elif grade == Grade.THREE:
            return Colors.GRADE_3
        elif grade == Grade.TWO:
            return Colors.GRADE_2
        elif grade == Grade.ABSENT:
            return Colors.GRADE_ABSENT
        else:  # EMPTY
            return Colors.GRADE_EMPTY
    
    @staticmethod
    def hex_to_rgb(hex_color: str) -> Tuple[int, int, int]:
        """Конвертировать HEX в RGB"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    
    @staticmethod
    def rgb_to_hex(rgb: Tuple[int, int, int]) -> str:
        """Конвертировать RGB в HEX"""
        return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"
    
    @staticmethod
    def blend_colors(color1: str, color2: str, ratio: float = 0.5) -> str:
        """Смешать два цвета (ratio: 0.0 = color1, 1.0 = color2)"""
        rgb1 = DesignSystem.hex_to_rgb(color1)
        rgb2 = DesignSystem.hex_to_rgb(color2)
        
        blended = tuple(
            int(rgb1[i] * (1 - ratio) + rgb2[i] * ratio)
            for i in range(3)
        )
        return DesignSystem.rgb_to_hex(blended)
    
    @staticmethod
    def with_opacity(color: str, opacity: float, background: str = None) -> str:
        """Создать цвет с прозрачностью путем смешивания с фоном"""
        if background is None:
            background = Colors.BACKGROUND
        return DesignSystem.blend_colors(background, color, opacity)

